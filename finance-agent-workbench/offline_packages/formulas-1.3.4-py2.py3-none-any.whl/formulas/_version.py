#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# Copyright 2016-2026 European Commission (JRC);
# Licensed under the EUPL (the 'Licence');
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at: http://ec.europa.eu/idabc/eupl

__all__ = ['__version__', '__updated__', '__title__', '__author__',
           '__license__', '__copyright__']

#: Authoritative project's PEP 440 version.
__version__ = version = "1.3.4"  # Also update README.rst

# Please UPDATE TIMESTAMP WHEN BUMPING VERSIONS AND BEFORE RELEASE.
#: Release date.
__updated__ = "2026-03-11 18:35:00"

__title__ = 'formulas'

__author__ = 'Vincenzo Arcidiacono <vinci1it2000@gmail.com>'

__license__ = 'EUPL, see LICENSE.txt'

__copyright__ = 'Copyright 2016-2026, Vincenzo Arcidiacono'
